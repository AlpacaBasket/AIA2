(require '[cgsx.tools.matcher :refer :all])
(require '[clojure.set :refer :all])
(require '[clojure.pprint :refer :all])

(declare finalise-results update-state-map apply-op apply-all)


(defn ops-search
  [start goal ops & {:keys [world debug]
                     :or {debug  false
                          world  #{}}}]
  ; using sets for state tuples...
  (let [start {:state (set start) :path () :cmds () :txt ()}
        world (set world)
        goal? (fn [state] (mfind* [goal (into world (:state state))] state))
        ]
    (or (goal? start)
      (finalise-results
        (loop [waiting (list start)
               visited #{}
               ]
          (when debug (pprint (list 'waiting= waiting 'visited= visited)))
          (if (empty? waiting) nil
            (let [ [next & waiting] waiting
                   {:keys [state path cmds]} next
                   visited? (partial contains? visited)
                   ]
              (when debug (pprint (list 'next-state= state)))
              (if (visited? state)
                (recur waiting visited)
                (let [succs (remove visited? (apply-all ops state world))
                      g     (some goal? succs)
                      ]
                  (if g (update-state-map next g)
                    (recur
                      (concat waiting (map #(update-state-map next %) succs))
                      (conj visited state) ))
                  )))))
        ))))


(defn update-state-map
  [old successor]
  {:state (:state successor)
   :path  (cons (:state old) (:path old))
   :cmds  (cons (:cmd successor) (:cmds old))
   :txt   (cons (:txt successor) (:txt old))
   })


(defn finalise-results [state-map]
  "reverses relevant parts of results"
  (if-not (map? state-map)
    ;; leave it as it is
    state-map
    ;; else
    {:state (:state state-map)
     :path  (reverse (:path state-map))
     :cmds  (reverse (:cmds state-map))
     :txt   (reverse (:txt state-map))
     }
    ))


(defn apply-op [op state world]
  (mfor* [(:pre op) (seq (into world state))]
    {:state (union (set (mout (:add op)))
              (difference state (set (mout (:del op)))))
     :cmd   (mout (:cmd op))
     :txt   (mout (:txt op))
     }
    ))


(defn apply-all [ops state world]
  (reduce concat
    (map (fn [x] (apply-op (x ops) state world))
      (keys ops)
      )))


;======================
; testing
;======================

;(def ops
;  '{pickup {:pre ((agent ?agent)
;                   (manipulable ?obj)
;                   (at ?agent ?place)
;                   (on ?obj   ?place)
;                   (holds ?agent nil)
;                   )
;            :add ((holds ?agent ?obj))
;            :del ((on ?obj   ?place)
;                   (holds ?agent nil))
;            :txt (pickup ?obj from ?place)
;            :cmd [grasp ?obj]
;            }
;    drop    {:pre ((at ?agent ?place)
;                    (holds ?agent ?obj)
;                    (:guard (? obj))
;                    )
;             :add ((holds ?agent nil)
;                    (on ?obj   ?place))
;             :del ((holds ?agent ?obj))
;             :txt (drop ?obj at ?place)
;             :cmd [drop ?obj]
;             }
;    move    {:pre ((agent ?agent)
;                    (at ?agent ?p1)
;                    (connects ?p1 ?p2)
;                    )
;             :add ((at ?agent ?p2))
;             :del ((at ?agent ?p1))
;             :txt (move ?p1 to ?p2)
;             :cmd [move ?p2]
;             }
;    })
;
;
;(def state1
;  '#{(at R table)
;     (on book table)
;     (on spud table)
;     (holds R nil)
;     (connects table bench)
;     (manipulable book)
;     (manipulable spud)
;     (agent R)
;     })
;
;